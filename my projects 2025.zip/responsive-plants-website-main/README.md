# Responsive Plants Website 🎍 
## [Watch it on youtube](https://youtu.be/lpzExNZDizI)
### Responsive Plants Website 🎍

- Responsive Plants Website Using HTML, CSS and JavaScript.
- Contains animations when scrolling.
- Includes a dark and light mode.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![plants website](/preview.png)
